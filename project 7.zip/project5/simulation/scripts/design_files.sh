#!/bin/bash

# list of design files to be compiled

ver_files=("../../source/upsampler.v"
	  "../testbench/upsampler_tb.v")	
